document.getElementById("applyStyles").addEventListener("click", async () => {
  const css = `
      .ds-markdown.ds-markdown--block {
          direction: rtl;
      }
  
      .md-code-block{
          direction: ltr;
      }
    `;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.insertCSS({
    target: { tabId: tab.id },
    css,
  });
});
